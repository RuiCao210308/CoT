# OpenEMMA-OFT 850scenes Remaining Pipeline

- start_time: Tue Jun  2 19:27:52 CST 2026
- project: /root/autodl-tmp/CoT
- train_jsonl: /root/autodl-tmp/action_chunks_gt_waypoint_trainval_850scenes_train.jsonl
- test_jsonl: /root/autodl-tmp/action_chunks_gt_waypoint_trainval_850scenes_test.jsonl
- train_cache: /root/autodl-tmp/qwen_hidden_cache_trainval_850scenes/train_cache.pt
- test_cache: /root/autodl-tmp/qwen_hidden_cache_trainval_850scenes/test_cache.pt
- logs: /root/autodl-tmp/logs_850_remaining_20260602_192752

## Data size
   14415 /root/autodl-tmp/action_chunks_gt_waypoint_trainval_850scenes_train.jsonl
    3584 /root/autodl-tmp/action_chunks_gt_waypoint_trainval_850scenes_test.jsonl
   17999 total


## Eval Summary

| model | samples | speed | curv_x100 | overall | gate | speed_gate | curv_gate |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fusion_850 | 3584 | 1.0694 | 0.8426 | 0.9560 |  |  |  |
| gated_graft_850 | 3584 | 1.2113 | 0.8370 | 1.0241 | 0.5058 | 0.7909 | 0.2207 |
| gated_graft_trainval_850scenes_seed0_rs0.1_gw0.5_gate0_realbase | 3584 | 1.2113 | 0.8370 | 1.0241 | 0.5058 | 0.7909 | 0.2207 |
| gated_graft_trainval_850scenes_seed1_rs0.1_gw0.5_gate0_realbase | 3584 | 1.1040 | 0.8291 | 0.9665 | 0.5888 | 0.9227 | 0.2549 |
| gated_graft_trainval_850scenes_seed2_rs0.1_gw0.5_gate0_realbase | 3584 | 1.1367 | 0.8297 | 0.9832 | 0.5557 | 0.8668 | 0.2446 |

## Fusion eval



## Gated-GRAFT eval



## Scenario analysis



## Trajectory rollout analysis



- end_time: 2026-06-02T19:44:33.095122
