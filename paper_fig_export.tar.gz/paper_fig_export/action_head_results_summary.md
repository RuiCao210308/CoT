# OpenEMMA OFT-lite Action Head Results

## Eval Metrics

| model | split | num_samples | speed_mae_mps | curvature_mae_x100 | curvature_mae_1pm | overall_l1_train_scale |
| --- | --- | --- | --- | --- | --- | --- |
| ego-only | train | 100 | 2.4187 | 0.7253 | 0.0073 | 1.5720 |
| ego-only | held-out | 114 | 5.6917 | 1.2525 | 0.0125 | 3.4721 |
| qwen-hidden-only | train | 100 | 2.9078 | 0.7526 | 0.0075 | 1.8302 |
| fusion | train | 100 | 1.5379 | 0.7603 | 0.0076 | 1.1491 |
| fusion | held-out | 114 | 4.9524 | 1.2854 | 0.0129 | 3.1189 |

## Relative Changes

| comparison | metric | baseline | candidate | relative_change_pct | interpretation |
| --- | --- | --- | --- | --- | --- |
| fusion vs ego-only train overall_l1 | overall_l1_train_scale | 1.5720 | 1.1491 | 26.9016 | improvement |
| fusion vs ego-only held-out overall_l1 | overall_l1_train_scale | 3.4721 | 3.1189 | 10.1718 | improvement |
| fusion vs ego-only train speed_mae | speed_mae_mps | 2.4187 | 1.5379 | 36.4168 | improvement |
| fusion vs ego-only held-out speed_mae | speed_mae_mps | 5.6917 | 4.9524 | 12.9891 | improvement |
| fusion vs ego-only train curvature_mae_x100 | curvature_mae_x100 | 0.7253 | 0.7603 | -4.8303 | regression |
| fusion vs ego-only held-out curvature_mae_x100 | curvature_mae_x100 | 1.2525 | 1.2854 | -2.6314 | regression |
| qwen-hidden-only vs ego-only train overall_l1 | overall_l1_train_scale | 1.5720 | 1.8302 | -16.4248 | regression |
| fusion vs qwen-hidden-only train overall_l1 | overall_l1_train_scale | 1.8302 | 1.1491 | 37.2141 | improvement |

## Conclusion

Fusion improves overall action-space prediction over ego-only on train and held-out splits.
The held-out improvement is modest.
The gain mainly comes from speed prediction.
Curvature prediction remains a bottleneck.
